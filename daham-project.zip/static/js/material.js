/* static/js/material.js */

// [자재 평균 단가 및 기준값]
const PR = {
    molding: 4000, gypsum: 5500, twoby: 6000, stud: 3500, runner: 3000,
    silk: 35000, wide: 18000, small: 5000, 
    tile_wall: 25000, tile_floor: 25000, 
    bond_cera: 25000, bond_dry: 22000, bond_floor: 8000, cement_w: 6000,
    floor_1_8: 35000, floor_2_0: 42000, floor_2_2: 50000, floor_3_2: 75000, floor_4_5: 105000, floor_5_0: 130000,
    sink_eco: 120000, sink_std: 220000, sink_high: 400000,
    fridge_eco: 450000, fridge_std: 700000, fridge_high: 1200000,
    ward_swing_eco: 110000, ward_swing_std: 140000, ward_slide_eco: 140000, ward_slide_std: 170000,
    shoe_eco: 100000, shoe_std: 130000, balcony_eco: 90000, balcony_std: 120000
};

let currentTempItem = null;

function formatWon(num) { return num.toLocaleString() + "원"; }

// ==========================================
// [핵심] 뒤로가기 제스처(스와이프) 제어 로직 (Hash Routing)
// ==========================================

// 1. 페이지 로드 시 & 해시 변경 시(스와이프 등) 화면 처리
window.addEventListener('load', renderView);
window.addEventListener('hashchange', renderView);

function renderView() {
    // 현재 주소의 해시값(#뒤의 단어)을 가져옵니다.
    // 예: material.html#carpentry -> 'carpentry'
    const hash = location.hash.replace('#', '');

    // 1. 모든 페이지 숨기기
    document.querySelectorAll('.page-container').forEach(e => e.classList.remove('active'));

    // 2. 해시값에 맞는 페이지 보여주기
    if (hash === '') {
        // 해시가 없으면 '메인 메뉴(아이콘들)' 보여줌
        document.getElementById('mainMenu').classList.add('active');
        // 결과창들은 닫아주기 (깔끔하게)
        document.querySelectorAll('.result-box').forEach(e => e.style.display = 'none');
    } else {
        // 해시가 있으면 해당 페이지(page-carpentry 등) 보여줌
        const targetPage = document.getElementById('page-' + hash);
        if (targetPage) {
            targetPage.classList.add('active');
        } else {
            // 없는 페이지면 메인 메뉴로
            document.getElementById('mainMenu').classList.add('active');
        }
    }
    
    // 글로벌 합계 업데이트
    updateGlobalSummary();
}

// 2. 메뉴 클릭 시 이동 함수 (기록 남기기)
function goPage(pageName) {
    // 주소 뒤에 #pageName을 붙입니다. 
    // 브라우저는 이것을 "페이지 이동"으로 인식하여 히스토리를 쌓습니다.
    location.hash = pageName;
}

// 3. 상단 뒤로가기 화살표(←) 버튼 기능
function goHome() {
    if (location.hash) {
        // 상세 페이지에 있다면 -> 브라우저 뒤로가기 (메뉴로 이동)
        // 스와이프와 동일한 동작을 합니다.
        history.back(); 
    } else {
        // 이미 메뉴 페이지라면 -> 진짜 메인(/main)으로 이동
        location.href = '/main'; 
    }
}

// ------------------------------------------

function switchTab(targetId, btn) {
    const parent = btn.parentElement;
    parent.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    
    if(targetId.startsWith('f-')) {
        ['f-sink','f-wardrobe','f-storage'].forEach(id => document.getElementById(id).style.display = 'none');
        document.getElementById(targetId).style.display = 'block';
    } else if(targetId.startsWith('c-')) {
        ['c-molding','c-wall'].forEach(id => document.getElementById(id).style.display = 'none');
        document.getElementById(targetId).style.display = 'block';
    } else {
        document.getElementById('paper-dim-box').style.display = 'none';
        document.getElementById('paper-area-box').style.display = 'none';
        document.getElementById(targetId).style.display = 'block';
    }
    document.querySelectorAll('.result-box').forEach(e => e.style.display = 'none');
}

function togglePaperScope() {
    const scope = document.querySelector('input[name="paper-scope"]:checked').value;
    const inputD = document.getElementById('paper-d');
    const help = document.getElementById('paper-help-text');
    if (scope === 'wall') {
        inputD.style.display = 'none';
        help.innerText = '* 한 면 시공 시 가로와 높이만 입력하세요.';
    } else {
        inputD.style.display = 'block';
        help.innerText = '* 방 전체 시공 시 가로, 세로, 높이 모두 필요합니다.';
    }
}

// 견적 관리
function addToEstimate() {
    if(!currentTempItem) return alert("계산된 내용이 없습니다.");
    const list = JSON.parse(localStorage.getItem('daham_est_list')) || [];
    list.push(currentTempItem);
    localStorage.setItem('daham_est_list', JSON.stringify(list));
    alert("견적 리스트에 추가되었습니다.");
    updateGlobalSummary();
    document.querySelectorAll('.result-box').forEach(e => e.style.display = 'none');
}

function updateGlobalSummary() {
    const list = JSON.parse(localStorage.getItem('daham_est_list')) || [];
    let total = 0;
    list.forEach(item => total += item.cost);
    const totalEl = document.getElementById('global-total');
    const countEl = document.getElementById('global-count');
    if(totalEl) totalEl.innerText = formatWon(total);
    if(countEl) countEl.innerText = `(${list.length})`;
}

function renderTotalPage() {
    const list = JSON.parse(localStorage.getItem('daham_est_list')) || [];
    const box = document.getElementById('estimate-list-box');
    const empty = document.getElementById('empty-msg');
    box.innerHTML = '';
    if(list.length === 0) {
        empty.style.display = 'block';
    } else {
        empty.style.display = 'none';
        list.forEach((item, idx) => {
            const html = `
                <div class="est-item">
                    <span class="est-cat">${item.cat}</span>
                    <button class="btn-del" onclick="deleteItem(${idx})">×</button>
                    <div class="est-desc">${item.desc}</div>
                    <div class="est-cost">${formatWon(item.cost)}</div>
                </div>`;
            box.insertAdjacentHTML('beforeend', html);
        });
    }
}

function deleteItem(idx) {
    if(!confirm('삭제하시겠습니까?')) return;
    const list = JSON.parse(localStorage.getItem('daham_est_list')) || [];
    list.splice(idx, 1);
    localStorage.setItem('daham_est_list', JSON.stringify(list));
    renderTotalPage();
    updateGlobalSummary();
}

function clearAll() {
    if(!confirm('전체 내역을 삭제하시겠습니까?')) return;
    localStorage.removeItem('daham_est_list');
    renderTotalPage();
    updateGlobalSummary();
}

function drawResult(targetId, list, totalCost, categoryName, detailSummary) {
    currentTempItem = {
        cat: categoryName || '기타',
        desc: detailSummary || list.map(i => i.k + ' ' + i.v).join(', '),
        cost: totalCost
    };
    const box = document.getElementById(targetId);
    let html = '';
    list.forEach(item => { 
        if(item.k.startsWith('■')) html += `<div style="font-weight:bold; color:#0A2342; margin-top:10px; margin-bottom:5px; border-bottom:1px solid #ddd; padding-bottom:3px; display:flex; justify-content:space-between;"><span>${item.k}</span><span style="font-weight:normal; font-size:13px; color:#666;">${item.v}</span></div>`;
        else html += `<div class="res-row"><span>${item.k}</span><div style="text-align:right;"><span class="res-val">${item.v}</span>${item.p ? `<span class="res-price">(${item.p})</span>` : ''}</div></div>`; 
    });
    if(totalCost > 0) html += `<div class="res-total">합계: ${formatWon(totalCost)}</div>`;
    html += `<button class="btn-add-list" onclick="addToEstimate()">+ 견적 리스트에 담기</button>`;
    box.innerHTML = html;
    box.style.display = 'block';
}

// ================= [계산 함수] =================

// 1. 목공
function calcMolding() {
    const w = parseFloat(document.getElementById('mol-w').value) || 0;
    const h = parseFloat(document.getElementById('mol-h').value) || 0;
    if(!w || !h) return alert("치수를 입력하세요.");
    const perimeter = (w + h) * 2;
    const count = Math.ceil(perimeter / 2400 * 1.1); 
    const cost = count * PR.molding;
    drawResult('res-molding', [{k: '방 둘레', v: (perimeter/1000).toFixed(1) + ' m', p: ''},{k: '천장 몰딩 (2.4m)', v: count + ' 개', p: formatWon(cost)}], cost, '목공', `천장몰딩: ${count}개 (방 ${w}x${h})`);
}
function calcWall() {
    const w = parseFloat(document.getElementById('wall-w').value) || 0;
    const h = parseFloat(document.getElementById('wall-h').value) || 0;
    const space = parseInt(document.querySelector('input[name="wall-space"]:checked').value);
    const ply = parseInt(document.querySelector('input[name="wall-ply"]:checked').value);
    const side = parseInt(document.querySelector('input[name="wall-side"]:checked').value);
    const type = document.querySelector('input[name="wall-type"]:checked').value;
    if(!w || !h) return alert("치수를 입력하세요.");
    const areaMm = w * h;
    const baseGypsum = (areaMm / 1000000) / 1.62; 
    const rawTotalGypsum = baseGypsum * ply * side;
    let lossFactor = rawTotalGypsum > 20 ? 1.15 : 1.1;
    const finalGypsum = Math.ceil(rawTotalGypsum * lossFactor);
    const gypsumCost = finalGypsum * PR.gypsum;
    let structHtml = [], structCost = 0; 
    if (type === 'steel') {
        const runnerCount = Math.ceil((w / 3000 * 2) * 1.1);
        const studCount = Math.ceil(((w / space) + 2) * 1.1);
        const rCost = runnerCount * PR.runner;
        const sCost = studCount * PR.stud;
        structCost = rCost + sCost;
        structHtml.push({k: '경량 러너', v: runnerCount + ' 개', p: formatWon(rCost)});
        structHtml.push({k: '경량 스터드', v: studCount + ' 개', p: formatWon(sCost)});
    } else {
        const lengthMm = (w * 2) + (h * (Math.ceil(w / space) + 1));
        const count = Math.ceil((lengthMm / 3600) * 1.1);
        structCost = count * PR.twoby;
        structHtml.push({k: '투바이 (12자)', v: count + ' 개', p: formatWon(structCost)});
    }
    const items = [{k: '가벽 면적', v: (areaMm/1000000).toFixed(1) + ' ㎡', p: ''},{k: `석고보드 (${ply}P)`, v: `${finalGypsum} 장`, p: formatWon(gypsumCost)},...structHtml];
    drawResult('res-wall', items, gypsumCost + structCost, '목공', `가벽(${type === 'twoby' ? '목' : '경량'}): ${(areaMm/1000000).toFixed(1)}㎡`);
}

// 2. 타일
function calcTile() {
    const rw = parseFloat(document.getElementById('tile-room-w').value) || 0;
    const rd = parseFloat(document.getElementById('tile-room-d').value) || 0;
    const rh = parseFloat(document.getElementById('tile-room-h').value) || 0;
    const bondType = document.querySelector('input[name="tile-bond"]:checked').value;
    if(!rw || !rd) return alert("치수를 입력하세요.");
    const wallAreaM2 = ((rw + rd) * 2 * rh) / 1000000;
    const floorAreaM2 = (rw * rd) / 1000000;
    const wallBoxNet = Math.ceil(wallAreaM2 / 1.44); 
    let wallBoxLoss = Math.ceil(wallBoxNet * 0.1); if(wallBoxLoss < 1) wallBoxLoss = 1; 
    const wallBoxTotal = wallBoxNet + wallBoxLoss;
    const wallCost = wallBoxTotal * PR.tile_wall;
    const floorBoxNet = Math.ceil(floorAreaM2 / 1.44);
    let floorBoxLoss = Math.ceil(floorBoxNet * 0.1); if(floorBoxLoss < 1) floorBoxLoss = 1;
    const floorBoxTotal = floorBoxNet + floorBoxLoss;
    const floorCost = floorBoxTotal * PR.tile_floor;
    const wallBondDiv = bondType === 'cera' ? 6 : 5;
    const wallBondCount = Math.ceil(wallAreaM2 / wallBondDiv);
    const wallBondPrice = bondType === 'cera' ? PR.bond_cera : PR.bond_dry;
    const wallBondName = bondType === 'cera' ? '세라픽스' : '드라이픽스';
    const wallBondCost = wallBondCount * wallBondPrice;
    const floorBondCount = Math.ceil(floorAreaM2 / 5);
    const floorBondCost = floorBondCount * PR.bond_floor;
    const cementCount = Math.ceil((wallAreaM2 + floorAreaM2) / 30);
    const cementCost = cementCount * PR.cement_w;
    drawResult('res-tile', [
        {k: `■ 타일 물량`, v: '', p: ''},
        {k: '벽 타일', v: wallBoxTotal + ' Box', p: formatWon(wallCost)},
        {k: '바닥 타일', v: floorBoxTotal + ' Box', p: formatWon(floorCost)},
        {k: `■ 부자재`, v: '', p: ''},
        {k: `벽: ${wallBondName}`, v: wallBondCount + ' 개', p: formatWon(wallBondCost)},
        {k: '바닥: 압착', v: floorBondCount + ' 포', p: formatWon(floorBondCost)},
        {k: '줄눈: 백시멘트', v: cementCount + ' 포', p: formatWon(cementCost)},
    ], wallCost + floorCost + wallBondCost + floorBondCost + cementCost, '타일', `욕실/타일 (벽:${wallAreaM2.toFixed(1)}㎡ 바닥:${floorAreaM2.toFixed(1)}㎡)`);
}

// 3. 도배
function calcPaper() {
    const type = document.getElementById('paper-type').value; 
    const isDimMode = document.getElementById('paper-dim-box').style.display !== 'none';
    const scope = document.querySelector('input[name="paper-scope"]:checked') ? document.querySelector('input[name="paper-scope"]:checked').value : 'room';
    let pyeong = 0, desc = "";
    if (isDimMode) {
        const w = parseFloat(document.getElementById('paper-w').value) || 0;
        const h = parseFloat(document.getElementById('paper-h').value) || 0;
        if (scope === 'room') {
            const d = parseFloat(document.getElementById('paper-d').value) || 0;
            if(!w || !d || !h) return alert("치수를 모두 입력하세요.");
            pyeong = (((w * d) + ((w + d) * 2 * h)) / 1000000) / 3.3;
            desc = "실측(전체)";
        } else {
            if(!w || !h) return alert("가로, 높이를 입력하세요.");
            pyeong = ((w * h) / 1000000) / 3.3;
            desc = "실측(한면)";
        }
    } else {
        const py = parseFloat(document.getElementById('paper-py').value) || 0;
        if(!py) return alert("평수를 입력하세요.");
        pyeong = py * 2.5; 
        desc = "공급면적 기준";
    }
    let roll = 0, price = 0, typeName = "";
    if(type === 'silk') { roll = Math.ceil(pyeong / 5); price = roll * PR.silk; typeName = "실크"; }
    else if(type === 'wide') { roll = Math.ceil(pyeong / 5); price = roll * PR.wide; typeName = "광폭합지"; }
    else { roll = Math.ceil(pyeong / 2); price = roll * PR.small; typeName = "소폭합지"; }
    drawResult('res-paper', [{k: '도배 평수', v: pyeong.toFixed(1) + ' 평', p: desc},{k: `소요 롤 수 (${typeName})`, v: roll + ' 롤', p: formatWon(price)}], price, '도배', `${typeName} 도배 (${desc})`);
}

// 4. 장판
function calcFloor() {
    const py = parseFloat(document.getElementById('floor-py').value) || 0;
    if(!py) return alert("평수를 입력하세요.");
    const tVal = document.querySelector('input[name="floor-t"]:checked').value;
    let unitPrice = PR['floor_' + tVal.replace('.','_')] || PR.floor_1_8;
    const realPy = Math.ceil(py * 1.1);
    const cost = realPy * unitPrice;
    drawResult('res-floor', [{k: '선택 두께', v: tVal + ' T', p: ''},{k: '소요 평수', v: realPy + ' 평', p: '로스포함'}], cost, '바닥재', `장판 ${tVal}T (${realPy}평)`);
}

// 5. 가구
function calcSink() {
    const topMm = parseFloat(document.getElementById('sink-top-mm').value) || 0;
    const botMm = parseFloat(document.getElementById('sink-bot-mm').value) || 0;
    if(topMm === 0 && botMm === 0) return alert("길이를 입력하세요.");
    const grade = document.querySelector('input[name="sink-grade"]:checked').value;
    const hasFridge = document.getElementById('sink-fridge').checked;
    let unitPrice = PR['sink_' + grade];
    let gradeName = grade === 'eco' ? "가성비" : (grade === 'high' ? "고급형" : "표준형");
    const topCost = Math.round((topMm / 300) * unitPrice * 0.4);
    const botCost = Math.round((botMm / 300) * unitPrice * 0.6);
    const fridgeCost = hasFridge ? PR['fridge_' + grade] : 0;
    let list = [{k: '등급', v: gradeName, p: ''}];
    if(topMm > 0) list.push({k: '상부장', v: (topMm/300).toFixed(1)+'자', p: formatWon(topCost)});
    if(botMm > 0) list.push({k: '하부장', v: (botMm/300).toFixed(1)+'자', p: formatWon(botCost)});
    if(hasFridge) list.push({k: '냉장고장', v: '1칸', p: formatWon(fridgeCost)});
    drawResult('res-sink', list, topCost+botCost+fridgeCost, '가구', `싱크대(${gradeName}) 상:${topMm} 하:${botMm}`);
}
function calcWardrobe() {
    const w = parseFloat(document.getElementById('ward-w').value) || 0;
    if(!w) return alert("길이를 입력하세요.");
    const type = document.querySelector('input[name="ward-type"]:checked').value;
    const grade = document.querySelector('input[name="ward-grade"]:checked').value;
    let unitPrice = PR['ward_' + type + '_' + grade];
    const cost = Math.round((w / 300) * unitPrice);
    drawResult('res-wardrobe', [{k: '길이', v: (w/300).toFixed(1)+'자', p:''}], cost, '가구', `붙박이장 (${type}/${grade})`);
}
function calcStorage() {
    const w = parseFloat(document.getElementById('stor-w').value) || 0;
    if(!w) return alert("길이를 입력하세요.");
    const type = document.querySelector('input[name="stor-type"]:checked').value;
    const grade = document.querySelector('input[name="stor-grade"]:checked').value;
    let unitPrice = PR[type + '_' + grade];
    const cost = Math.round((w / 300) * unitPrice);
    drawResult('res-storage', [{k: '길이', v: (w/300).toFixed(1)+'자', p:''}], cost, '가구', `${type==='shoe'?'신발장':'베란다장'} (${grade})`);
}